SWEP.Base = "homigrad_base"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.PrintName = "AKM"
SWEP.Author = "Izhevsk Machine-Building Plant"
SWEP.Instructions = "An extraordinarily potent instrument of power, this steel 7.62x39mm selective fire, gas-operated rifle with a rotating bolt, capable of firing in either semi-automatic or fully automatic mode, is the epitome of Soviet military might in the mid-20th century. With a cyclic rate of fire of around 600 rounds per minute and a 10-, 20-, or 30-round detachable box magazine, this AKM, designed by the renowned Mikhail Kalashnikov, stands as a symbol of the USSR’s technological progress. Its robust design and reliable performance in harsh conditions underline its reputation as a weapon that has left an indelible mark on global warfare"
SWEP.Category = "Weapons - Assault Rifles"
SWEP.Slot = 2
SWEP.SlotPos = 10
SWEP.ViewModel = ""
SWEP.WorldModel = "models/weapons/w_rif_ak47.mdl"
SWEP.WorldModelFake = "models/weapons/arccw/c_ur_ak.mdl"

DEFINE_BASECLASS( "homigrad_base" )

SWEP.FakePos = Vector(-12, 2.52, 5.5)
SWEP.FakeAng = Angle(-1, 0.25, 5.5)
SWEP.AttachmentPos = Vector(3,3,-26.8)
SWEP.AttachmentAng = Angle(0,-1.5,0)
SWEP.FakeAttachment = "1"
SWEP.FakeBodyGroups = "01010080102"

SWEP.FakeEjectBrassATT = "2"

SWEP.FakeViewBobBone = "CAM_Homefield"

SWEP.FakeReloadSounds = {
	[0.22] = "weapons/universal/uni_crawl_l_03.wav",
	[0.34] = "weapons/newakm/akmm_magout.wav",
	[0.38] = "weapons/newakm/akmm_magout_rattle.wav",

	[0.62] = "weapons/newakm/akmm_magin.wav",
	[0.81] = "weapons/universal/uni_crawl_l_03.wav",
	[0.99] = "weapons/universal/uni_crawl_l_04.wav",

}

SWEP.FakeEmptyReloadSounds = {

	[0.22] = "weapons/universal/uni_crawl_l_03.wav",
	[0.34] = "weapons/newakm/akmm_magout.wav",
	[0.4] = "weapons/newakm/akmm_magout_rattle.wav",
	[0.62] = "weapons/newakm/akmm_magin.wav",

	[0.83] = "weapons/newakm/akmm_boltback.wav",
	[0.86] = "weapons/newakm/akmm_boltrelease.wav",
	[1.01] = "weapons/universal/uni_crawl_l_04.wav",
}

SWEP.MagModel = "models/btk/nam_akmmag.mdl"

SWEP.lmagpos = Vector(0,0,1)
SWEP.lmagang = Angle(30,0,0)
SWEP.lmagpos2 = Vector(0,-2.5,1)
SWEP.lmagang2 = Angle(0,0,-90)

SWEP.FakeViewBobBone = "ValveBiped.Bip01_R_Hand"
SWEP.FakeViewBobBaseBone = "ValveBiped.Bip01_L_UpperArm"
SWEP.ViewPunchDiv = 70
SWEP.FakeMagDropBone = 57

SWEP.AnimList = {
	["idle"] = "idle",
	["reload"] = "reload",
	["reload_empty"] = "reload_empty",
	-- ["unload"] = "reload",
	-- ["unload_1"] = "idle",
	-- ["reload_unloaded"] = "reload_empty",
}
SWEP.UnloadAnimTime = 3

local vector_full = Vector(1,1,1)

SWEP.AnimsEvents = {
	["unload"] = {
		[-1] = function(self)
			local wm = self:GetWM()
			wm:ManipulateBoneScale(55, vector_origin)
			wm:ManipulateBoneScale(56, vector_origin)
			wm:ManipulateBoneScale(58, vector_full)
			wm:ManipulateBoneScale(57, vector_full)
		end,
		[0.22-0.15] = function(self) self:EmitSound("weapons/universal/uni_crawl_l_03.wav") end,
		[0.19] = function(self) self:EmitSound("weapons/newakm/akmm_magout.wav") end,
		[0.23] = function(self) self:GetWM():EmitSound("weapons/newakm/akmm_magout_rattle.wav") end,
		[0.45] = function(self)
			local wm = self:GetWM()
			wm:ManipulateBoneScale(55, vector_origin)
			wm:ManipulateBoneScale(56, vector_origin)
			wm:ManipulateBoneScale(57, vector_origin)
			wm:ManipulateBoneScale(58, vector_origin)

			self:PlayAnim("unload_1",0.5)

		end
	},
	["unload_1"] = {
		[0.1] = function(self) self:EmitSound("weapons/universal/uni_crawl_l_04.wav") end,
		[0.4] = function(self)
			self:PlayAnim("jamfix",1.8)
		end
	},
	["jamfix"] = {
		[0.02] = function(self) self:EmitSound("weapons/universal/uni_crawl_l_01.wav") end,
		[0.22] = function(self) self:EmitSound("weapons/newakm/akmm_boltback.wav") end,
		[0.31] = function(self) self:EmitSound("weapons/newakm/akmm_boltrelease.wav") end,
	}
}

function SWEP:RevertMag()
	-- local wm = self:GetWM()

	-- if IsValid(wm) and wm:GetManipulateBoneScale(55):IsEqualTol(vector_origin, 0.1) then
	-- 	wm:ManipulateBoneScale(55, vector_full)
	-- 	wm:ManipulateBoneScale(56, vector_full)
	-- 	wm:ManipulateBoneScale(57, vector_origin)
	-- 	wm:ManipulateBoneScale(58, vector_origin)
	-- end
end

if CLIENT then
	SWEP.FakeReloadEvents = {
		[0.15] = function( self, timeMul )
			local wm = self:GetWM()
			wm:ManipulateBoneScale(55, vector_origin)
			wm:ManipulateBoneScale(56, vector_origin)
			wm:ManipulateBoneScale(57, vector_full)
			wm:ManipulateBoneScale(58, vector_full)
		end,
		[0.16] = function( self, timeMul )
			self:GetOwner():PullLHTowards("ValveBiped.Bip01_Spine2", 0.58 * timeMul)
		end,
		[0.27] = function( self, timeMul )
			local wm = self:GetWM()
			wm:ManipulateBoneScale(55, vector_full)
			wm:ManipulateBoneScale(56, vector_full)
			wm:ManipulateBoneScale(58, vector_full)
			wm:ManipulateBoneScale(57, vector_full)
		end,
		
		[0.40] = function(self,timeMul)
			if self:Clip1() < 1 then
				hg.CreateMag( self, Vector(50,10,10) )
				self:GetWM():ManipulateBoneScale(57, vector_origin)
				self:GetWM():ManipulateBoneScale(58, vector_origin)
				--self:GetOwner():PullLHTowards("ValveBiped.Bip01_L_Thigh", 0.5 * timeMul)
			end
		end,
		[0.85] = function(self,timeMul)
			self:GetWM():ManipulateBoneScale(57, vector_origin)
			self:GetWM():ManipulateBoneScale(58, vector_origin)
		end
	}
end

function SWEP:ModelCreated(model)
	model:ManipulateBoneScale(57, vector_origin)
	model:ManipulateBoneScale(58, vector_origin)
	model:SetBodyGroups(self.FakeBodyGroups)
end

SWEP.GunCamPos = Vector(4,-15,-6)
SWEP.GunCamAng = Angle(190,-5,-100)

SWEP.ReloadHold = nil
SWEP.FakeVPShouldUseHand = false

SWEP.weaponInvCategory = 1
SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 30
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "7.62x39 mm"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 50
SWEP.Primary.Spread = 0
SWEP.Primary.Force = 50
SWEP.ShockMultiplier = 2

SWEP.Primary.Sound = {"weapons/newakm/akmm_tp.wav", 85, 90, 100}
SWEP.Primary.SoundFP = {"weapons/newakm/akmm_fp.wav", 85, 90, 100}

SWEP.SupressedSound = {"weapons/newakm/akmm_suppressed_tp.wav", 65, 90, 100}
SWEP.SupressedSoundFP = {"weapons/newakm/akmm_suppressed_fp.wav", 65, 90, 100}

SWEP.Primary.SoundEmpty = {"weapons/newakm/akmm_empty.wav", 75, 100, 105, CHAN_WEAPON, 2}

SWEP.DistSound = "weapons/newakm/akmm_dist.wav"



SWEP.WepSelectIcon2 = Material("pwb/sprites/akm.png")
SWEP.IconOverride = "entities/arc9_eft_akm.png"
SWEP.ScrappersSlot = "Primary"
SWEP.availableAttachments = {
	barrel = {
		[1] = {"supressor1", Vector(0,0,0), {}},
		[2] = {"supressor6", Vector(0,0,0), {}},
		["mount"] = Vector(-2,0.2,0),
		["mountAngle"] = Angle(0,0,0)
	},
	sight = {
		["mountType"] = {"picatinny", "dovetail"},
		["mount"] = {["dovetail"] = Vector(-25, 2.2, -0.45),["picatinny"] = Vector(-24.5, 2.65, -0.22)},
	},
	mount = {
		["picatinny"] = {
			"mount3",
			Vector(-22.5, 0, -1.26),
			{},
			["mountType"] = "picatinny",
		},
		["dovetail"] = {
			"empty",
			Vector(0, 0, 0),
			{},
			["mountType"] = "dovetail",
		},
	},
	underbarrel = {
		["mountType"] = "picatinny",
		["mount"] = Vector(-7,1.4,-0.2),
		["mountAngle"] = Angle(0, 0, 0),
	},
	grip = {
		["mount"] = Vector(-16.2,-0.1,-0.2),
		["mountType"] = "akm"
	},
}

SWEP.Primary.Wait = 0.095
SWEP.ReloadTime = 5
SWEP.ReloadSoundes = {
	"none",
	"none",
	"none",
	"weapons/tfa_ins2/ak103/ak103_magout.wav",
	"none",
	"weapons/tfa_ins2/ak103/ak103_magin.wav",
	"none",
	"weapons/tfa_ins2/ak103/ak103_boltback.wav",
	"weapons/tfa_ins2/ak103/ak103_boltrelease.wav",
	"none",
	"none",
	"none"
}

SWEP.LocalMuzzlePos = Vector(26.986,-0.2,2.741)
SWEP.LocalMuzzleAng = Angle(-0.4,0,0)
SWEP.WeaponEyeAngles = Angle(0,0,0)

SWEP.PPSMuzzleEffect = "pcf_jack_mf_mrifle1" -- shared in sh_effects.lua

SWEP.HoldType = "rpg"
SWEP.ZoomPos = Vector(0, -0.0054, 4.8688)

SWEP.RHandPos = Vector(-12, -1, 4)
SWEP.LHandPos = Vector(7, -3, -2)
SWEP.Spray = {}
for i = 1, 30 do
	SWEP.Spray[i] = Angle(-0.02 - math.cos(i) * 0.03, math.cos(i * i) * 0.02, 0) * 2
end

SWEP.Ergonomics = 0.8
SWEP.HaveModel = "models/pwb/weapons/w_akm.mdl"
--SWEP.ShellEject = "EjectBrass_338Mag"
SWEP.CustomShell = "762x39"

SWEP.Penetration = 15
SWEP.WorldPos = Vector(4, -1, -1.5)
SWEP.WorldAng = Angle(0, 0, 0)
SWEP.UseCustomWorldModel = true
--https://youtu.be/I7TUHPn_W8c?list=RDEMAfyWQ8p5xUzfAWa3B6zoJg
SWEP.attPos = Vector(0.2, -2.6, 27)
SWEP.attAng = Angle(-0, 0.3, 0)
SWEP.lengthSub = 20
SWEP.handsAng = Angle(3, -1, 0)
SWEP.AimHands = Vector(-4, 0.5, -4)


SWEP.weight = 4

--local to head
SWEP.RHPos = Vector(3,-6.5,3.5)
SWEP.RHAng = Angle(0,-8,90)
--local to rh
SWEP.LHPos = Vector(15,1.5,-3.5)
SWEP.LHAng = Angle(-110,-180,0)

SWEP.ShootAnimMul = 7

function SWEP:DrawPost()
	local wep = self:GetWeaponEntity()
	self.vec = self.vec or Vector(0,0,0)
	local vec = self.vec
	if CLIENT and IsValid(wep) then
		self.shooanim = Lerp(FrameTime()*15,self.shooanim or 0,self.ReloadSlideOffset)
		vec[1] = 0*self.shooanim
		vec[2] = 1*self.shooanim
		vec[3] = 0*self.shooanim
		wep:ManipulateBonePosition(8,vec,false)
	end
end
local lfang4 = Angle(0,70,0)
local lfang3 = Angle(0,-25,0)
local lfang2 = Angle(0,46,0)
local lfang1 = Angle(0,-30,0)
local lfang0 = Angle(0,-7,0)
local vec_zero = Vector(0,0,0)
local l_finger02 = Angle(-10,0,0)
function SWEP:AnimHoldPost()

end
-- Inspect Assault

SWEP.InspectAnimWepAng = {
	Angle(0,0,0),
	Angle(4,4,15),
	Angle(10,15,25),
	Angle(10,15,25),
	Angle(10,15,25),
	Angle(-6,-15,-15),
	Angle(1,15,-45),
	Angle(15,25,-55),
	Angle(15,25,-55),
	Angle(15,25,-55),
	Angle(0,0,0),
	Angle(0,0,0)
}